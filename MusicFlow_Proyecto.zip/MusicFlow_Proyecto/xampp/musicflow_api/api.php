<?php
/**
 * API única de MusicFlow.  La app llama:  POST api.php?action=XXX   con cuerpo JSON.
 * Respuesta siempre:  { "ok": true|false, "msg": "...", "data": ... }
 * Seguridad: password_hash/verify (RN03), consultas preparadas (anti inyección SQL),
 * validación de entradas y comprobación de propiedad de playlists (RN10).
 */
header('Content-Type: application/json; charset=utf-8');
function out($ok, $data = null, $msg = '') {
  echo json_encode(['ok' => $ok, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE); exit;
}
set_exception_handler(function ($e) { out(false, null, 'Error del servidor: ' . $e->getMessage()); });
require 'config.php';

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $_GET['action'] ?? '';
$uid = (int)($in['user_id'] ?? 0);

function q($sql, $p = []) { global $pdo; $s = $pdo->prepare($sql); $s->execute($p); return $s; }

// Devuelve canciones con la marca "fav" (si el usuario la tiene en favoritos).
function songs($tail, $params = []) {
  global $uid;
  $sql = "SELECT c.id, c.titulo, c.artista, c.genero, c.ruta_audio, c.album, c.portada, "
       . "EXISTS(SELECT 1 FROM favoritos f WHERE f.cancion_id=c.id AND f.usuario_id=?) AS fav "
       . "FROM canciones c " . $tail;
  $rows = q($sql, array_merge([$uid], $params))->fetchAll();
  foreach ($rows as &$r) { $r['id'] = (int)$r['id']; $r['fav'] = (int)$r['fav']; }
  return $rows;
}
function ownsPlaylist($pid) { global $uid;
  return q("SELECT 1 FROM playlists WHERE id=? AND usuario_id=?", [$pid, $uid])->fetch() !== false; }

// ---------- Acciones públicas (sin sesión) ----------
if ($action === 'register') {                                   // HU01
  $n = trim($in['nombre'] ?? ''); $c = strtolower(trim($in['correo'] ?? '')); $p = $in['password'] ?? '';
  if ($n === '' || !filter_var($c, FILTER_VALIDATE_EMAIL) || strlen($p) < 6)
    out(false, null, 'Completa nombre, correo válido y contraseña (mín. 6 caracteres)');
  if (q("SELECT id FROM usuarios WHERE correo=?", [$c])->fetch()) out(false, null, 'Ese correo ya está registrado');
  q("INSERT INTO usuarios (nombre,correo,password_hash) VALUES (?,?,?)", [$n, $c, password_hash($p, PASSWORD_DEFAULT)]);
  out(true, ['id' => (int)$pdo->lastInsertId(), 'nombre' => $n], 'Registro exitoso');
}
if ($action === 'login') {                                      // HU02
  $c = strtolower(trim($in['correo'] ?? ''));
  $u = q("SELECT id,nombre,password_hash FROM usuarios WHERE correo=?", [$c])->fetch();
  if (!$u || !password_verify($in['password'] ?? '', $u['password_hash'])) out(false, null, 'Correo o contraseña incorrectos');
  out(true, ['id' => (int)$u['id'], 'nombre' => $u['nombre']], 'Bienvenido');
}


// ---------- Acciones con sesión ----------
if ($uid <= 0) out(false, null, 'Sesión no válida');

switch ($action) {
  case 'songs':                                                  // HU04 + HU15 (búsqueda)
    $s = '%' . trim($in['q'] ?? '') . '%';
    out(true, songs("WHERE c.titulo LIKE ? OR c.artista LIKE ? ORDER BY c.titulo", [$s, $s]));

  case 'playlists':
    out(true, q("SELECT p.id,p.nombre,(SELECT COUNT(*) FROM playlist_canciones pc WHERE pc.playlist_id=p.id) AS total
                 FROM playlists p WHERE p.usuario_id=? ORDER BY p.id DESC", [$uid])->fetchAll());

  case 'playlist_create':                                        // HU09
    $n = trim($in['nombre'] ?? ''); if ($n === '') out(false, null, 'Escribe un nombre');
    q("INSERT INTO playlists (usuario_id,nombre) VALUES (?,?)", [$uid, $n]);
    out(true, null, 'Playlist creada');

  case 'playlist_delete':
    q("DELETE FROM playlists WHERE id=? AND usuario_id=?", [(int)$in['playlist_id'], $uid]);
    out(true, null, 'Playlist eliminada');

  case 'playlist_songs':
    $pid = (int)$in['playlist_id']; if (!ownsPlaylist($pid)) out(false, null, 'No es tu playlist');
    out(true, songs("JOIN playlist_canciones pc ON pc.cancion_id=c.id WHERE pc.playlist_id=? ORDER BY pc.agregado", [$pid]));

  case 'playlist_add':                                           // HU10
    $pid = (int)$in['playlist_id']; if (!ownsPlaylist($pid)) out(false, null, 'No es tu playlist');
    $st = q("INSERT IGNORE INTO playlist_canciones (playlist_id,cancion_id) VALUES (?,?)", [$pid, (int)$in['song_id']]);
    out($st->rowCount() > 0, null, $st->rowCount() > 0 ? 'Canción agregada' : 'Ya estaba en la playlist');

  case 'playlist_remove':                                        // HU11 (RN14: no borra del catálogo)
    $pid = (int)$in['playlist_id']; if (!ownsPlaylist($pid)) out(false, null, 'No es tu playlist');
    q("DELETE FROM playlist_canciones WHERE playlist_id=? AND cancion_id=?", [$pid, (int)$in['song_id']]);
    out(true, null, 'Canción quitada de la playlist');

  case 'fav_toggle':                                             // HU12
    $sid = (int)$in['song_id'];
    if (q("SELECT 1 FROM favoritos WHERE usuario_id=? AND cancion_id=?", [$uid, $sid])->fetch()) {
      q("DELETE FROM favoritos WHERE usuario_id=? AND cancion_id=?", [$uid, $sid]); out(true, ['fav' => false]);
    }
    q("INSERT INTO favoritos (usuario_id,cancion_id) VALUES (?,?)", [$uid, $sid]); out(true, ['fav' => true]);

  case 'favorites':                                              // HU13
    out(true, songs("JOIN favoritos fv ON fv.cancion_id=c.id WHERE fv.usuario_id=? ORDER BY c.titulo", [$uid]));

  case 'history_add':                                            // HU14 / RN09
    q("INSERT INTO historial (usuario_id,cancion_id) VALUES (?,?)", [$uid, (int)$in['song_id']]);
    out(true);

  case 'history':
    out(true, songs("JOIN historial h ON h.cancion_id=c.id WHERE h.usuario_id=? ORDER BY h.id DESC LIMIT 50", [$uid]));

  default: out(false, null, 'Acción no válida');
    // ===== PERFIL =====
  case 'profile_get':
    $u = q("SELECT nombre,correo,foto FROM usuarios WHERE id=?", [$uid])->fetch();
    if (!$u) out(false, null, 'Usuario no encontrado');
    $url = null;
    if (!empty($u['foto']) && is_file(__DIR__ . '/' . $u['foto']))
      $url = $u['foto'] . '?v=' . filemtime(__DIR__ . '/' . $u['foto']);   // ?v= evita imagen en caché
    out(true, ['nombre' => $u['nombre'], 'correo' => $u['correo'], 'foto' => $url]);

  case 'profile_name':
    $n = trim($in['nombre'] ?? '');
    if ($n === '' || mb_strlen($n) > 80) out(false, null, 'Nombre no válido (1 a 80 caracteres)');
    q("UPDATE usuarios SET nombre=? WHERE id=?", [$n, $uid]);
    out(true, ['nombre' => $n], 'Nombre actualizado');

  case 'profile_email':
    $new = strtolower(trim($in['correo'] ?? ''));
    if (!filter_var($new, FILTER_VALIDATE_EMAIL)) out(false, null, 'Correo no válido');
    if (!checkPass($in['password'] ?? '')) out(false, null, 'La contraseña actual es incorrecta');
    if (q("SELECT id FROM usuarios WHERE correo=? AND id<>?", [$new, $uid])->fetch())
      out(false, null, 'Ese correo ya está registrado por otro usuario');
    q("UPDATE usuarios SET correo=? WHERE id=?", [$new, $uid]);
    out(true, ['correo' => $new], 'Correo actualizado');

  case 'profile_password':
    $nueva = $in['nueva'] ?? ''; $conf = $in['confirmar'] ?? '';
    if (!checkPass($in['actual'] ?? '')) out(false, null, 'La contraseña actual es incorrecta');
    if (strlen($nueva) < 6) out(false, null, 'La nueva contraseña debe tener al menos 6 caracteres');
    if ($nueva !== $conf) out(false, null, 'Las contraseñas nuevas no coinciden');
    q("UPDATE usuarios SET password_hash=? WHERE id=?", [password_hash($nueva, PASSWORD_DEFAULT), $uid]);
    out(true, null, 'Contraseña actualizada');

  case 'profile_photo':                                  // la app envía la imagen JPG en base64
    $raw = base64_decode($in['imagen'] ?? '', true);
    if ($raw === false || strlen($raw) > 2 * 1024 * 1024) out(false, null, 'Imagen no válida o mayor a 2 MB');
    $info = @getimagesizefromstring($raw);
    if (!$info || $info[2] !== IMAGETYPE_JPEG) out(false, null, 'Solo se permite imagen JPG');
    $dir = __DIR__ . '/uploads'; if (!is_dir($dir)) mkdir($dir, 0755, true);
    $rel = 'uploads/u' . $uid . '.jpg';
    file_put_contents(__DIR__ . '/' . $rel, $raw);
    q("UPDATE usuarios SET foto=? WHERE id=?", [$rel, $uid]);
    out(true, ['foto' => $rel . '?v=' . time()], 'Foto actualizada');
}
// Verifica la contraseña ACTUAL del usuario (nunca se devuelve ni se compara en texto plano).
function checkPass($p) { global $uid;
  $h = q("SELECT password_hash FROM usuarios WHERE id=?", [$uid])->fetchColumn();
  return $h && password_verify($p, $h); }
