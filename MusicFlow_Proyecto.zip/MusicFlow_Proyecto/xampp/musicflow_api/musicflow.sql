-- MusicFlow - Base de datos (importar en phpMyAdmin > Importar)
CREATE DATABASE IF NOT EXISTS musicflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE musicflow;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  correo VARCHAR(120) NOT NULL UNIQUE,          -- RN02: correo único
  password_hash VARCHAR(255) NOT NULL,          -- RN03: nunca texto plano
  creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE canciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(120) NOT NULL,
  artista VARCHAR(120) NOT NULL,
  genero VARCHAR(50) NOT NULL,
  ruta_audio VARCHAR(255) NOT NULL              -- "audio/x.mp3" (en el servidor) o URL completa
);
CREATE TABLE playlists (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,                      -- RN05: pertenece a un único usuario
  nombre VARCHAR(80) NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
CREATE TABLE playlist_canciones (                -- RN06: una canción en varias playlists
  playlist_id INT NOT NULL,
  cancion_id INT NOT NULL,
  agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (playlist_id, cancion_id),
  FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
  FOREIGN KEY (cancion_id) REFERENCES canciones(id) ON DELETE CASCADE
);
CREATE TABLE favoritos (
  usuario_id INT NOT NULL,
  cancion_id INT NOT NULL,
  PRIMARY KEY (usuario_id, cancion_id),         -- RN08: sin duplicados
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (cancion_id) REFERENCES canciones(id) ON DELETE CASCADE
);
CREATE TABLE historial (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  cancion_id INT NOT NULL,
  reproducido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (cancion_id) REFERENCES canciones(id) ON DELETE CASCADE
);

-- Canciones de prueba (SoundHelix, audio libre para pruebas).
-- Para usar tus propios mp3: ponlos en htdocs/musicflow_api/audio/ y cambia ruta_audio a 'audio/tu.mp3'
INSERT INTO canciones (titulo, artista, genero, ruta_audio) VALUES
('Aurora', 'Lumen', 'Electrónica', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'),
('Noches de Lima', 'Costa Norte', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'),
('Rumbo al Mar', 'Costa Norte', 'Pop', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'),
('Pulso', 'Lumen', 'Electrónica', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'),
('Cuerdas Rotas', 'Eco Andino', 'Rock', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3'),
('Tormenta', 'Eco Andino', 'Rock', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3'),
('Brisa Lenta', 'Marea Azul', 'Chill', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3'),
('Atardecer', 'Marea Azul', 'Chill', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3');
