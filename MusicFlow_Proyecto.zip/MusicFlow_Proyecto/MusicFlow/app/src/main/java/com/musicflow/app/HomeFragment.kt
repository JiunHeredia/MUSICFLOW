package com.musicflow.app

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * INICIO: saludo según la hora, búsqueda, "Escuchado recientemente" (con portadas reales),
 * categorías de Explorar y banner hacia Playlist.
 */
class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        val main = activity as MainActivity

        v.findViewById<TextView>(R.id.tvGreeting).text = greeting()
        v.findViewById<TextView>(R.id.tvSearch).setOnClickListener { main.openCatalog() }
        v.findViewById<TextView>(R.id.tvSeeAll).setOnClickListener { main.openHistory() }
        v.findViewById<TextView>(R.id.btnGoPlaylist).setOnClickListener { main.openLibrary(1) }

        val row1 = v.findViewById<LinearLayout>(R.id.rowExplore1)
        val row2 = v.findViewById<LinearLayout>(R.id.rowExplore2)
        addExplore(row1, "♫", "Música") { main.openCatalog() }
        addExplore(row1, "◉", "Podcasts") { soon() }
        addExplore(row2, "★", "Éxitos") { soon() }
        addExplore(row2, "☺", "Estado de ánimo") { soon() }

        loadRecent()
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            h in 5..11 -> "¡Buenos días!"
            h in 12..18 -> "¡Buenas tardes!"
            else -> "¡Buenas noches!"
        }
    }

    private fun addExplore(row: LinearLayout, icon: String, label: String, onClick: () -> Unit) {
        val item = layoutInflater.inflate(R.layout.item_explore, row, false)
        item.findViewById<TextView>(R.id.tvIcon).text = icon
        item.findViewById<TextView>(R.id.tvLabel).text = label
        item.setOnClickListener { onClick() }
        row.addView(item)
    }

    private fun loadRecent() {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("songs", "user_id" to Session.userId, "q" to "")
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val picks = r.getJSONArray("data").toSongs().take(3)

            val box = view?.findViewById<LinearLayout>(R.id.recentBox) ?: return@launch
            box.removeAllViews()
            picks.forEachIndexed { i, song ->
                val card = layoutInflater.inflate(R.layout.item_recent, box, false)
                val cv = card.findViewById<ImageView>(R.id.viewCover)
                cv.setBackgroundResource(Covers.of(song.id))
                CoverLoader.bind(cv, song)                       // portada real
                card.findViewById<TextView>(R.id.tvTitle).text = song.title
                card.findViewById<TextView>(R.id.tvArtist).text = song.artist
                card.setOnClickListener { PlayerManager.playQueue(picks, i) }
                card.findViewById<View>(R.id.btnPlay).setOnClickListener { PlayerManager.playQueue(picks, i) }
                card.findViewById<View>(R.id.btnMore).setOnClickListener { showMenu(it, song, picks, i) }
                box.addView(card)
            }
        }
    }

    private fun showMenu(anchor: View, song: Song, list: List<Song>, index: Int) {
        PopupMenu(requireContext(), anchor).apply {
            menu.add(0, 1, 0, "Reproducir")
            menu.add(0, 2, 1, if (song.fav) "Quitar de favoritos" else "Agregar a favoritos")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> PlayerManager.playQueue(list, index)
                    2 -> toggleFav(song)
                }
                true
            }
        }.show()
    }

    private fun toggleFav(song: Song) {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("fav_toggle", "user_id" to Session.userId, "song_id" to song.id)
            if (r.optBoolean("ok")) {
                song.fav = !song.fav
                toast(if (song.fav) "Agregada a favoritos" else "Quitada de favoritos")
            } else toast(r.optString("msg"))
        }
    }

    private fun soon() = toast("Próximamente")
    private fun toast(m: String) { context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() } }
}