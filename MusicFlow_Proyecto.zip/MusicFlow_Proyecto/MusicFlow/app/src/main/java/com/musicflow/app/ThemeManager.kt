package com.musicflow.app

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/**
 * MODO CLARO / OSCURO. La preferencia se guarda en SharedPreferences ("mf_theme"),
 * separada de la sesión, así NO se borra al cerrar sesión y se mantiene al reabrir la app.
 */
object ThemeManager {
    private const val FILE = "mf_theme"
    private const val KEY = "dark"

    fun isDark(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun apply(c: Context) = AppCompatDelegate.setDefaultNightMode(
        if (isDark(c)) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)

    /** Guarda y aplica: Android recrea las pantallas abiertas con los colores del otro modo. */
    fun set(c: Context, dark: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY, dark).apply()
        apply(c)
    }
}