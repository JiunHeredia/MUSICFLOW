package com.musicflow.app

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

/**
 * BIBLIOTECA: contiene dos opciones que se cambian sin salir de la pantalla:
 *  - Favoritos (SongsFragment en modo "favorites")
 *  - Playlist  (PlaylistsFragment)
 * La lógica de ambos no cambia; solo se muestran aquí dentro.
 */
class LibraryFragment : Fragment(R.layout.fragment_library) {
    private var tab = -1          // 0 = Favoritos, 1 = Playlist

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        if (tab < 0) tab = arguments?.getInt("tab") ?: 0
        v.findViewById<TextView>(R.id.tabFav).setOnClickListener { select(0) }
        v.findViewById<TextView>(R.id.tabPlaylist).setOnClickListener { select(1) }
        select(tab)
    }

    private fun select(i: Int) {
        tab = i
        val v = view ?: return
        style(v.findViewById(R.id.tabFav), i == 0)
        style(v.findViewById(R.id.tabPlaylist), i == 1)
        val child: Fragment = if (i == 0) SongsFragment.newInstance("favorites") else PlaylistsFragment()
        childFragmentManager.beginTransaction().replace(R.id.libContainer, child).commit()
    }

    private fun style(t: TextView, active: Boolean) {
        t.setBackgroundResource(if (active) R.drawable.bg_icon_red else R.drawable.bg_card)
        t.setTextColor(ContextCompat.getColor(requireContext(), if (active) R.color.white else R.color.mf_muted))
    }

    /** MainActivity lo llama para resaltar la canción que suena dentro de Favoritos. */
    fun refreshHighlight() {
        (childFragmentManager.findFragmentById(R.id.libContainer) as? SongsFragment)?.refreshHighlight()
    }

    companion object {
        fun newInstance(tab: Int) = LibraryFragment().apply { arguments = Bundle().apply { putInt("tab", tab) } }
    }
}