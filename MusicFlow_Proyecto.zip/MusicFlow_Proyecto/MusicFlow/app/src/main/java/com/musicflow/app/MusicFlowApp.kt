package com.musicflow.app

import android.app.Application

/** Se ejecuta al abrir la app: prepara la sesión y aplica el tema guardado (claro u oscuro). */
class MusicFlowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Session.init(this)
        ThemeManager.apply(this)
    }
}