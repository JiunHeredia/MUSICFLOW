package com.musicflow.app

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Pantalla de texto para "Acerca de la app" y "Ayuda y soporte" (según el extra "type"). */
class InfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)
        val about = intent.getStringExtra("type") == "about"
        findViewById<TextView>(R.id.tvInfoTitle).text = if (about) "Acerca de la app" else "Ayuda y soporte"
        findViewById<TextView>(R.id.tvInfoBody).text = if (about) ABOUT else HELP
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
    }

    companion object {
        private val ABOUT = """
            MusicFlow  ·  versión 0.75

            Aplicación móvil Android para la gestión y reproducción personalizada de contenido musical.

            Proyecto final del curso Desarrollo de Aplicaciones Móviles, UPN 2026-2.

            Integrantes:
            • Gabriel Jeremías Cuadrado Vergaray
            • Francis Damian Cueva Vara
            • Josepmir Jiun Mel Heredia Yachi
            • Diego Gustavo Pichilingue Vela
            • Jean Piero Yupanqui Celmi

            Tecnologías: Android Studio, Kotlin, XML, PHP (API REST), MySQL, XAMPP y JSON.
        """.trimIndent()

        private val HELP = """
            ¿Necesitas ayuda?

            • Catálogo: toca la barra de búsqueda de Inicio para ver todas las canciones.
            • Favoritos y playlists: están dentro de Biblioteca.
            • Cambiar correo o contraseña: en Editar perfil se te pedirá tu contraseña actual.
            • Si la app dice "Sin conexión", verifica que el servidor (Apache y MySQL) esté encendido y que el celular esté en la misma red.

            Contacto: soporte@musicflow.com (correo de ejemplo del prototipo académico).
        """.trimIndent()
    }
}