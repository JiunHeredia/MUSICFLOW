package com.musicflow.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

/** Descarga una imagen del servidor (la foto de perfil) fuera del hilo principal. */
object ImageLoader {
    suspend fun load(url: String): Bitmap? = withContext(Dispatchers.IO) {
        try { URL(url).openStream().use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
    }
}