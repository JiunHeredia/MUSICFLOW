package com.musicflow.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.launch

/**
 * REPRODUCTOR EXPANDIDO. No tiene reproductor propio: controla PlayerManager (el mismo del mini reproductor).
 *  - Se actualiza solo escuchando PlayerManager (addListener) y con un temporizador de 500 ms para el progreso.
 *  - Favoritos: fav_toggle en la API; al abrir cada canción se consulta "favorites" para mostrar el estado real.
 *  - Playlists: playlists / playlist_add / playlist_create (la API evita duplicados, RN06).
 *  - Portada: imagen del servidor si la canción tiene "portada"; si no, degradado de color.
 */
class PlayerActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: View
    private lateinit var ivCover: ImageView
    private lateinit var tvFallback: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvAlbum: TextView
    private lateinit var btnFav: TextView
    private lateinit var btnPlay: TextView
    private lateinit var seek: SeekBar
    private lateinit var tvCur: TextView
    private lateinit var tvTotal: TextView
    private lateinit var ivShuffle: ImageView
    private lateinit var ivTimer: ImageView
    private lateinit var tvTimer: TextView
    private var shownSongId = -1
    private var dragging = false

    private val listener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 500) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayerManager.current == null) { finish(); return }
        setContentView(R.layout.activity_player)
        window.setBackgroundDrawable(ColorDrawable(0xFF0B0B0D.toInt()))
        @Suppress("DEPRECATION") run { window.statusBarColor = 0xFF0B0B0D.toInt() }
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false

        root = findViewById(R.id.root); ivCover = findViewById(R.id.ivCover); tvFallback = findViewById(R.id.tvCoverFallback)
        tvTitle = findViewById(R.id.tvTitle); tvArtist = findViewById(R.id.tvArtist); tvAlbum = findViewById(R.id.tvAlbum)
        btnFav = findViewById(R.id.btnFav); btnPlay = findViewById(R.id.btnPlay); seek = findViewById(R.id.seek)
        tvCur = findViewById(R.id.tvCur); tvTotal = findViewById(R.id.tvTotal)
        ivShuffle = findViewById(R.id.ivShuffle); ivTimer = findViewById(R.id.ivTimer); tvTimer = findViewById(R.id.tvTimer)

        // Portada cuadrada (máx. 320 dp) y con esquinas redondeadas
        val size = minOf(resources.displayMetrics.widthPixels - dp(40), dp(320))
        findViewById<FrameLayout>(R.id.coverBox).layoutParams =
            LinearLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(16) }
        ivCover.clipToOutline = true

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu() }
        btnFav.setOnClickListener { toggleFav() }
        btnPlay.setOnClickListener { PlayerManager.toggle() }
        findViewById<View>(R.id.btnNext).setOnClickListener { PlayerManager.next() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { PlayerManager.prev() }
        ivShuffle.setOnClickListener {
            PlayerManager.toggleShuffle()
            toast(if (PlayerManager.shuffle) "Reproducción aleatoria activada" else "Reproducción aleatoria desactivada")
        }
        ivTimer.setOnClickListener { showSleepDialog() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) tvCur.text = fmt(p) }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { PlayerManager.seekTo(seek.progress); dragging = false }
        })

        PlayerManager.addListener(listener)
        refresh()
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
    override fun onDestroy() { super.onDestroy(); PlayerManager.removeListener(listener) }

    @Suppress("DEPRECATION")
    override fun finish() { super.finish(); overridePendingTransition(R.anim.stay, R.anim.slide_down) }

    // ---------- Actualizar la pantalla con el estado real del reproductor ----------
    private fun refresh() {
        val s = PlayerManager.current
        if (s == null) { finish(); return }
        tvTitle.text = s.title; tvArtist.text = s.artist
        tvAlbum.text = if (s.album.isNotBlank()) "Álbum: ${s.album}" else s.genre
        btnPlay.text = if (PlayerManager.isPlaying) "⏸" else "▶"
        ivShuffle.setColorFilter(if (PlayerManager.shuffle) red() else Color.WHITE)
        ivTimer.setColorFilter(if (PlayerManager.sleepEndsAt > 0) red() else Color.WHITE)
        if (s.id != shownSongId) {              // solo cuando cambia la canción
            shownSongId = s.id
            applyCover(s); applyFav(s); syncFav(s)
        }
    }

    private fun tick() {
        val d = PlayerManager.duration; val p = PlayerManager.position
        if (d > 0 && !dragging) { seek.max = d; seek.progress = p; tvCur.text = fmt(p) }
        tvTotal.text = fmt(d)
        val left = PlayerManager.sleepRemainingMs()
        tvTimer.text = if (left > 0) "${left / 60000 + 1} min" else ""
    }

    private fun applyCover(s: Song) {
        // Fondo con degradado basado en el color de la portada
        val top = ColorUtils.blendARGB(Covers.colorOf(s.id), Color.BLACK, 0.45f)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, 0xFF0B0B0D.toInt()))
        // Portada de respaldo (degradado) mientras no haya imagen
        ivCover.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Covers.lightOf(s.id), Covers.colorOf(s.id))).apply { cornerRadius = dp(20).toFloat() }
        ivCover.setImageDrawable(null); tvFallback.visibility = View.VISIBLE
        // Portada real del servidor, si la canción la tiene
        if (s.cover.isNotBlank()) lifecycleScope.launch {
            val bmp = ImageLoader.load(Api.fileUrl(s.cover))
            if (bmp != null && PlayerManager.current?.id == s.id) { ivCover.setImageBitmap(bmp); tvFallback.visibility = View.GONE }
        }
    }

    // ---------- Favoritos ----------
    private fun applyFav(s: Song) {
        btnFav.text = if (s.fav) "♥" else "♡"
        btnFav.setTextColor(if (s.fav) red() else Color.WHITE)
    }

    /** Pregunta al servidor si la canción está en favoritos (así se sincroniza con las demás pantallas). */
    private fun syncFav(s: Song) {
        lifecycleScope.launch {
            val r = Api.call("favorites", "user_id" to Session.userId)
            if (!r.optBoolean("ok")) return@launch
            s.fav = r.getJSONArray("data").toSongs().any { it.id == s.id }
            if (PlayerManager.current?.id == s.id) applyFav(s)
        }
    }

    private fun toggleFav() {
        val s = PlayerManager.current ?: return
        lifecycleScope.launch {
            val r = Api.call("fav_toggle", "user_id" to Session.userId, "song_id" to s.id)
            if (r.optBoolean("ok")) {
                s.fav = r.getJSONObject("data").getBoolean("fav")
                if (PlayerManager.current?.id == s.id) applyFav(s)
                toast(if (s.fav) "Agregada a favoritos" else "Quitada de favoritos")
            } else toast(r.optString("msg"))
        }
    }

    // ---------- Temporizador de apagado ----------
    private fun showSleepDialog() {
        val labels = arrayOf("Desactivar", "5 minutos", "10 minutos", "15 minutos", "30 minutos", "45 minutos", "1 hora")
        val mins = intArrayOf(0, 5, 10, 15, 30, 45, 60)
        AlertDialog.Builder(this).setTitle("Temporizador de apagado").setItems(labels) { _, i ->
            PlayerManager.setSleepTimer(mins[i])
            toast(if (mins[i] == 0) "Temporizador desactivado" else "La música se detendrá en ${labels[i]}")
        }.show()
    }

    // ---------- Menú inferior (tres puntos) ----------
    private fun showMenu() {
        val s = PlayerManager.current ?: return
        val dlg = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_song_menu, null)
        v.findViewById<TextView>(R.id.sheetTitle).text = s.title
        v.findViewById<TextView>(R.id.sheetArtist).text = s.artist
        fun row(id: Int, action: () -> Unit) = v.findViewById<View>(id).setOnClickListener { dlg.dismiss(); action() }
        row(R.id.optPlaylist) { addToPlaylist(s) }
        row(R.id.optAlbum) { showAlbum(s) }
        row(R.id.optArtist) { showArtist(s) }
        row(R.id.optShare) { share(s) }
        row(R.id.optDetails) { showDetails(s) }
        row(R.id.optQueue) { PlayerManager.addToQueue(s); toast("Agregada a la cola de reproducción") }
        dlg.setContentView(v)
        dlg.setOnShowListener {
            dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        dlg.show()
    }

    private fun addToPlaylist(song: Song) {
        lifecycleScope.launch {
            val r = Api.call("playlists", "user_id" to Session.userId)
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val arr = r.getJSONArray("data")
            val ids = ArrayList<Int>(); val labels = ArrayList<String>(); val names = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                ids.add(o.getInt("id")); names.add(o.getString("nombre"))
                labels.add("${o.getString("nombre")}  (${o.optInt("total")} canciones)")
            }
            labels.add("＋  Crear nueva playlist")
            AlertDialog.Builder(this@PlayerActivity).setTitle("Agregar a playlist")
                .setItems(labels.toTypedArray()) { _, i ->
                    if (i == ids.size) createPlaylistAndAdd(song) else addTo(ids[i], song, names[i])
                }.setNegativeButton("Cancelar", null).show()
        }
    }

    private fun addTo(playlistId: Int, song: Song, name: String) {
        lifecycleScope.launch {
            val r = Api.call("playlist_add", "user_id" to Session.userId, "playlist_id" to playlistId, "song_id" to song.id)
            toast(if (r.optBoolean("ok")) "Agregada a \"$name\"" else r.optString("msg"))   // "Ya estaba en la playlist"
        }
    }

    private fun createPlaylistAndAdd(song: Song) {
        val et = EditText(this).apply { hint = "Nombre de la playlist"; setPadding(dp(24), dp(16), dp(24), dp(8)) }
        AlertDialog.Builder(this).setTitle("Nueva playlist").setView(et)
            .setPositiveButton("Crear y agregar") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) { toast("Escribe un nombre"); return@setPositiveButton }
                lifecycleScope.launch {
                    val c = Api.call("playlist_create", "user_id" to Session.userId, "nombre" to n)
                    if (!c.optBoolean("ok")) { toast(c.optString("msg")); return@launch }
                    // la API lista las más nuevas primero: la recién creada es la primera
                    val l = Api.call("playlists", "user_id" to Session.userId).optJSONArray("data")
                    val newId = if (l != null && l.length() > 0) l.getJSONObject(0).getInt("id") else null
                    if (newId != null) addTo(newId, song, n) else toast("Playlist creada")
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    // ---------- Álbum, artista, compartir, detalles ----------
    private fun showAlbum(s: Song) {
        if (s.album.isBlank()) { toast("Álbum no disponible para esta canción"); return }
        lifecycleScope.launch {
            val r = Api.call("songs", "user_id" to Session.userId, "q" to "")
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val list = r.getJSONArray("data").toSongs().filter { it.album.equals(s.album, true) }
            showSongList("Álbum: ${s.album}", list)
        }
    }

    private fun showArtist(s: Song) {
        val main = s.artist.substringBefore(",").substringBefore(" y ").trim()
        lifecycleScope.launch {
            val r = Api.call("songs", "user_id" to Session.userId, "q" to main)
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val list = r.getJSONArray("data").toSongs().filter { it.artist.contains(main, true) }
            showSongList("Canciones de $main", list)
        }
    }

    /** Lista de canciones; al tocar una, se reproduce con esa lista como cola. */
    private fun showSongList(title: String, list: List<Song>) {
        if (list.isEmpty()) { toast("No hay canciones para mostrar"); return }
        AlertDialog.Builder(this).setTitle(title)
            .setItems(list.map { it.title }.toTypedArray()) { _, i -> PlayerManager.playQueue(list, i) }
            .setNegativeButton("Cerrar", null).show()
    }

    private fun share(s: Song) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "🎵 Estoy escuchando \"${s.title}\" de ${s.artist} en MusicFlow")
        }
        startActivity(Intent.createChooser(i, "Compartir canción"))
    }

    private fun showDetails(s: Song) {
        val msg = "Título: ${s.title}\nArtista: ${s.artist}\nÁlbum: ${s.album.ifBlank { "No disponible" }}\n" +
                "Género: ${s.genre}\nDuración: ${fmt(PlayerManager.duration)}\nArchivo: ${Uri.decode(s.path)}"
        AlertDialog.Builder(this).setTitle("Detalles de la canción").setMessage(msg)
            .setPositiveButton("Cerrar", null).show()
    }

    // ---------- Utilidades ----------
    private fun red() = ContextCompat.getColor(this, R.color.mf_red)
    private fun fmt(ms: Int) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}