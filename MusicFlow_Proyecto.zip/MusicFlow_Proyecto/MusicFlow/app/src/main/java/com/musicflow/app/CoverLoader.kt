package com.musicflow.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * Pone la portada real de una canción (carpeta "covers" del servidor, columna "portada") en un ImageView.
 * - Caché en memoria: cada imagen se descarga una sola vez.
 * - Si la canción no tiene portada o falla la descarga, se queda el degradado de color del fondo.
 */
object CoverLoader {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) { override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024 }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun bind(iv: ImageView, song: Song) {
        iv.setImageDrawable(null)                        // limpia la imagen de la fila reciclada
        if (song.cover.isBlank()) { iv.tag = null; return }
        val url = Api.fileUrl(song.cover)
        iv.tag = url                                     // evita poner una imagen en la fila equivocada
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { download(url) }
            if (bmp != null) {
                cache.put(url, bmp)
                if (iv.tag == url) iv.setImageBitmap(bmp)
            }
        }
    }

    /** Descarga y reduce la imagen a máx. ~400 px para ahorrar memoria. */
    private fun download(url: String): Bitmap? = try {
        val bytes = URL(url).openStream().use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 400 || bounds.outHeight / sample > 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) { null }
}