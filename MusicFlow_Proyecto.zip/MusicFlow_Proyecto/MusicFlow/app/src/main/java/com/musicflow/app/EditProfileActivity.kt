package com.musicflow.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * EDITAR PERFIL.
 *  - Nombre: se edita en pantalla y se guarda con el botón Guardar (acción profile_name).
 *  - Foto: se elige de la galería, se muestra al instante y se sube al pulsar Guardar (profile_photo).
 *  - Correo / contraseña: ventanas que piden la contraseña ACTUAL; el servidor la verifica con
 *    password_verify (profile_email / profile_password). La contraseña nunca se muestra ni se recupera.
 *  - Modo claro/oscuro: interruptor guardado en ThemeManager.
 */
class EditProfileActivity : AppCompatActivity() {
    private lateinit var etName: EditText
    private lateinit var tvEmail: TextView
    private lateinit var tvInitial: TextView
    private lateinit var ivPhoto: ImageView
    private lateinit var btnSave: Button
    private lateinit var tvThemeIcon: TextView
    private lateinit var tvThemeTitle: TextView
    private lateinit var tvThemeSub: TextView
    private var loadedName = ""
    private var pendingPhoto: String? = null      // foto elegida (base64 JPG), se sube al Guardar

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) handlePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.userId == 0) { finish(); return }
        setContentView(R.layout.activity_edit_profile)

        etName = findViewById(R.id.etName); tvEmail = findViewById(R.id.tvEmail)
        tvInitial = findViewById(R.id.tvInitial); ivPhoto = findViewById(R.id.ivPhoto)
        btnSave = findViewById(R.id.btnSave)
        tvThemeIcon = findViewById(R.id.tvThemeIcon); tvThemeTitle = findViewById(R.id.tvThemeTitle)
        tvThemeSub = findViewById(R.id.tvThemeSub)
        ivPhoto.clipToOutline = true                // recorta la foto en círculo

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        btnSave.setOnClickListener { save() }
        findViewById<View>(R.id.btnCamera).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.tvChangePhoto).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.rowEmail).setOnClickListener { emailDialog() }
        findViewById<View>(R.id.rowPass).setOnClickListener { passwordDialog() }
        findViewById<View>(R.id.rowAbout).setOnClickListener { openInfo("about") }
        findViewById<View>(R.id.rowHelp).setOnClickListener { openInfo("help") }
        findViewById<View>(R.id.btnLogout).setOnClickListener { confirmLogout() }

        // Modo de visualización
        val sw = findViewById<MaterialSwitch>(R.id.swDark)
        sw.isChecked = ThemeManager.isDark(this)
        renderTheme(sw.isChecked)
        sw.setOnCheckedChangeListener { _, checked -> renderTheme(checked); ThemeManager.set(this, checked) }

        loadProfile()
    }

    private fun renderTheme(dark: Boolean) {
        tvThemeIcon.text = if (dark) "🌙" else "☀️"
        tvThemeTitle.text = if (dark) "Modo oscuro" else "Modo claro"
        tvThemeSub.text = if (dark) "Usa el tema oscuro en la app" else "Usa el tema claro en la app"
    }

    // ---------- Cargar datos del usuario ----------
    private fun loadProfile() {
        lifecycleScope.launch {
            val r = Api.call("profile_get", "user_id" to Session.userId)
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val d = r.getJSONObject("data")
            loadedName = d.getString("nombre")
            etName.setText(loadedName)
            tvEmail.text = d.getString("correo")
            tvInitial.text = loadedName.take(1).uppercase()
            if (!d.isNull("foto")) {
                val bmp = ImageLoader.load(Api.SERVER + "/" + d.getString("foto"))
                if (bmp != null) { ivPhoto.setImageBitmap(bmp); tvInitial.visibility = View.GONE }
            }
        }
    }

    // ---------- Guardar nombre y foto ----------
    private fun save() {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) { etName.error = "Escribe tu nombre"; return }
        if (name == loadedName && pendingPhoto == null) { toast("No hay cambios por guardar"); return }
        btnSave.isEnabled = false
        lifecycleScope.launch {
            var ok = true
            if (name != loadedName) {
                val r = Api.call("profile_name", "user_id" to Session.userId, "nombre" to name)
                if (r.optBoolean("ok")) {
                    loadedName = name; Session.save(Session.userId, name)
                    if (tvInitial.visibility == View.VISIBLE) tvInitial.text = name.take(1).uppercase()
                } else { ok = false; toast(r.optString("msg")) }
            }
            pendingPhoto?.let { img ->
                val r = Api.call("profile_photo", "user_id" to Session.userId, "imagen" to img)
                if (r.optBoolean("ok")) pendingPhoto = null else { ok = false; toast(r.optString("msg")) }
            }
            btnSave.isEnabled = true
            if (ok) toast("Perfil actualizado")
        }
    }

    // ---------- Foto desde la galería ----------
    private fun handlePicked(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeSquare(uri) }
            if (bmp == null) { toast("No se pudo leer la imagen"); return@launch }
            ivPhoto.setImageBitmap(bmp); tvInitial.visibility = View.GONE      // vista previa inmediata
            pendingPhoto = withContext(Dispatchers.IO) {
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
            toast("Foto lista. Pulsa Guardar para aplicarla")
        }
    }

    /** Lee la imagen reducida, corrige la rotación, la recorta cuadrada y la deja en máx. 512 px. */
    private fun decodeSquare(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            var bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return null

            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)

            val side = minOf(bmp.width, bmp.height)
            bmp = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side > 512) bmp = Bitmap.createScaledBitmap(bmp, 512, 512, true)
            bmp
        } catch (e: Exception) { null }
    }

    // ---------- Cambiar correo (pide contraseña actual) ----------
    private fun emailDialog() {
        val box = form()
        val etNew = field("Nuevo correo", false, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val etPass = field("Contraseña actual", true)
        box.addView(etNew); box.addView(etPass)
        val dlg = AlertDialog.Builder(this).setTitle("Cambiar correo").setView(box)
            .setPositiveButton("Guardar", null).setNegativeButton("Cancelar", null).create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {      // no se cierra si hay error
            val mail = etNew.text.toString().trim(); val pass = etPass.text.toString()
            if (!Patterns.EMAIL_ADDRESS.matcher(mail).matches()) { etNew.error = "Correo no válido"; return@setOnClickListener }
            if (pass.isEmpty()) { etPass.error = "Ingresa tu contraseña actual"; return@setOnClickListener }
            lifecycleScope.launch {
                val r = Api.call("profile_email", "user_id" to Session.userId, "correo" to mail, "password" to pass)
                if (r.optBoolean("ok")) {
                    tvEmail.text = r.getJSONObject("data").getString("correo")
                    dlg.dismiss()
                }
                toast(r.optString("msg"))
            }
        }
    }

    // ---------- Cambiar contraseña (actual + nueva + confirmar) ----------
    private fun passwordDialog() {
        val box = form()
        val etCur = field("Contraseña actual", true)
        val etNew = field("Nueva contraseña", true)
        val etCon = field("Confirmar nueva contraseña", true)
        box.addView(etCur); box.addView(etNew); box.addView(etCon)
        val dlg = AlertDialog.Builder(this).setTitle("Cambiar contraseña").setView(box)
            .setPositiveButton("Guardar", null).setNegativeButton("Cancelar", null).create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val cur = etCur.text.toString(); val nw = etNew.text.toString(); val con = etCon.text.toString()
            if (cur.isEmpty()) { etCur.error = "Ingresa tu contraseña actual"; return@setOnClickListener }
            if (nw.length < 6) { etNew.error = "Mínimo 6 caracteres"; return@setOnClickListener }
            if (nw != con) { etCon.error = "Las contraseñas no coinciden"; return@setOnClickListener }
            lifecycleScope.launch {
                val r = Api.call("profile_password", "user_id" to Session.userId,
                    "actual" to cur, "nueva" to nw, "confirmar" to con)
                if (r.optBoolean("ok")) dlg.dismiss()
                toast(r.optString("msg"))
            }
        }
    }

    // ---------- Otros / cerrar sesión ----------
    private fun openInfo(type: String) =
        startActivity(Intent(this, InfoActivity::class.java).putExtra("type", type))

    private fun confirmLogout() {
        AlertDialog.Builder(this).setTitle("Cerrar sesión").setMessage("¿Seguro que quieres cerrar sesión?")
            .setPositiveButton("Cerrar sesión") { _, _ ->
                PlayerManager.stop(); Session.clear()
                startActivity(Intent(this, AuthActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }.setNegativeButton("Cancelar", null).show()
    }

    // ---------- Utilidades ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun form() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0)
    }
    private fun field(hint: String, password: Boolean, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        this.hint = hint
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else type
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}