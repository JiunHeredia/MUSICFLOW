package com.musicflow.app

/** Portada de respaldo (degradado) por id, y sus colores para el fondo del reproductor expandido. */
object Covers {
    private val list = intArrayOf(
        R.drawable.cover_0, R.drawable.cover_1, R.drawable.cover_2, R.drawable.cover_3, R.drawable.cover_4
    )
    private val dark = intArrayOf(0xFFC0183C.toInt(), 0xFF2A62B8.toInt(), 0xFF5B34B8.toInt(), 0xFFD9692B.toInt(), 0xFF238A6E.toInt())
    private val light = intArrayOf(0xFFFF6B73.toInt(), 0xFF6EC6FF.toInt(), 0xFFA78BFA.toInt(), 0xFFFFD166.toInt(), 0xFF6EE7B7.toInt())

    fun of(id: Int): Int = list[id % list.size]
    fun colorOf(id: Int): Int = dark[id % dark.size]
    fun lightOf(id: Int): Int = light[id % light.size]
}