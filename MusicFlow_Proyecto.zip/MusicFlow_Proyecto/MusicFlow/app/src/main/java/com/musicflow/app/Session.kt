package com.musicflow.app

import android.content.Context
import android.content.SharedPreferences

/** Guarda quién inició sesión (HU02/HU03). Al cerrar sesión se borra y se vuelve al login. */
object Session {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("musicflow", Context.MODE_PRIVATE) }
    val userId: Int get() = sp.getInt("id", 0)
    val name: String get() = sp.getString("name", "") ?: ""
    fun save(id: Int, name: String) = sp.edit().putInt("id", id).putString("name", name).apply()
    fun clear() = sp.edit().clear().apply()
}
