package com.musicflow.app

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/**
 * PANTALLA DE ACCESO (HU01 registro + HU02 inicio de sesión).
 * Una sola pantalla con dos modos. Valida los datos en el celular y luego pregunta a la API;
 * la API es quien guarda el usuario en MySQL (contraseña con hash) y verifica credenciales.
 */
class AuthActivity : AppCompatActivity() {
    private var registerMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.userId != 0) { goMain(); return }          // ya había sesión activa
        setContentView(R.layout.activity_auth)
        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPass)
        val btn = findViewById<Button>(R.id.btnSubmit)
        val tvToggle = findViewById<TextView>(R.id.tvToggle)

        fun render() {
            etName.visibility = if (registerMode) View.VISIBLE else View.GONE
            btn.text = if (registerMode) "Crear cuenta" else "Iniciar sesión"
            tvToggle.text = if (registerMode) "¿Ya tienes cuenta? Inicia sesión" else "¿No tienes cuenta? Regístrate"
        }
        render()
        tvToggle.setOnClickListener { registerMode = !registerMode; render() }

        btn.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val pass = etPass.text.toString()
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { toast("Correo no válido"); return@setOnClickListener }
            if (pass.length < 6) { toast("La contraseña debe tener al menos 6 caracteres"); return@setOnClickListener }
            if (registerMode && name.isEmpty()) { toast("Ingresa tu nombre"); return@setOnClickListener }

            btn.isEnabled = false
            lifecycleScope.launch {
                val r = if (registerMode) Api.call("register", "nombre" to name, "correo" to email, "password" to pass)
                        else Api.call("login", "correo" to email, "password" to pass)
                btn.isEnabled = true
                if (r.optBoolean("ok")) {
                    val u = r.getJSONObject("data")
                    Session.save(u.getInt("id"), u.getString("nombre"))
                    toast(r.optString("msg")); goMain()
                } else toast(r.optString("msg"))
            }
        }
    }

    private fun goMain() { startActivity(Intent(this, MainActivity::class.java)); finish() }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
