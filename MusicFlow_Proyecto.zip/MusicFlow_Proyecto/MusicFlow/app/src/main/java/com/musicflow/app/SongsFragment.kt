package com.musicflow.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * LISTA DE CANCIONES REUTILIZABLE (según "mode"): catalog, favorites, history, playlist.
 * Cada fila: tocar = reproducir, ♥ = favorito, ＋ = agregar a playlist (✕ = quitar si estás en una playlist).
 */
class SongsFragment : Fragment(R.layout.fragment_songs) {
    private val mode get() = requireArguments().getString("mode")!!
    private val playlistId get() = requireArguments().getInt("pid")
    private lateinit var adapter: SongAdapter
    private lateinit var tvEmpty: TextView
    private lateinit var tvCardSub: TextView
    private var searchJob: Job? = null
    private var query = ""

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        val rv = v.findViewById<RecyclerView>(R.id.rv)
        val etSearch = v.findViewById<EditText>(R.id.etSearch)
        val tvTitle = v.findViewById<TextView>(R.id.tvListTitle)
        val card = v.findViewById<LinearLayout>(R.id.cardHeader)
        val tvCardIcon = v.findViewById<TextView>(R.id.tvCardIcon)
        val tvCardTitle = v.findViewById<TextView>(R.id.tvCardTitle)
        val tvPlayAll = v.findViewById<TextView>(R.id.tvPlayAll)
        tvEmpty = v.findViewById(R.id.tvEmpty)
        tvCardSub = v.findViewById(R.id.tvCardSub)

        adapter = SongAdapter(mode == "playlist",
            onPlay = { list, i -> PlayerManager.playQueue(list, i) },
            onFav = { toggleFav(it) },
            onMore = { if (mode == "playlist") removeFromPlaylist(it) else addToPlaylist(it) })
        rv.layoutManager = LinearLayoutManager(requireContext()); rv.adapter = adapter

        tvTitle.text = when (mode) {
            "catalog" -> "Canciones"; "favorites" -> "Favoritos"; "history" -> "Historial"; else -> "Playlist"
        }
        tvTitle.visibility = if (mode == "favorites") View.GONE else View.VISIBLE
        val showCard = mode == "favorites" || mode == "playlist"
        card.visibility = if (showCard) View.VISIBLE else View.GONE
        tvCardIcon.text = if (mode == "favorites") "♥" else "♫"
        tvCardTitle.text = if (mode == "favorites") "Tus favoritas" else requireArguments().getString("pname")
        tvPlayAll.setOnClickListener {
            if (adapter.items.isNotEmpty()) PlayerManager.playQueue(adapter.items, 0)
        }

        etSearch.visibility = if (mode == "catalog") View.VISIBLE else View.GONE
        etSearch.doAfterTextChanged { t ->
            searchJob?.cancel()
            searchJob = viewLifecycleOwner.lifecycleScope.launch { delay(300); query = t.toString().trim(); load() }
        }
    }

    override fun onResume() { super.onResume(); load() }

    /** MainActivity lo llama cuando cambia la canción para resaltar la fila que suena. */
    fun refreshHighlight() { if (::adapter.isInitialized) adapter.notifyDataSetChanged() }

    private fun load() {
        viewLifecycleOwner.lifecycleScope.launch {
            val uid = Session.userId
            val r = when (mode) {
                "catalog" -> Api.call("songs", "user_id" to uid, "q" to query)
                "favorites" -> Api.call("favorites", "user_id" to uid)
                "history" -> Api.call("history", "user_id" to uid)
                else -> Api.call("playlist_songs", "user_id" to uid, "playlist_id" to playlistId)
            }
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            adapter.items = r.getJSONArray("data").toSongs()
            adapter.notifyDataSetChanged()
            tvCardSub.text = "${adapter.items.size} canciones"
            tvEmpty.visibility = if (adapter.items.isEmpty()) View.VISIBLE else View.GONE
            tvEmpty.text = if (mode == "catalog") "No se encontraron canciones" else "Aún no hay canciones aquí"
        }
    }

    private fun toggleFav(song: Song) {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("fav_toggle", "user_id" to Session.userId, "song_id" to song.id)
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            if (mode == "favorites") load() else { song.fav = !song.fav; adapter.notifyDataSetChanged() }
        }
    }

    private fun addToPlaylist(song: Song) {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("playlists", "user_id" to Session.userId)
            val arr = r.optJSONArray("data")
            if (arr == null || arr.length() == 0) { toast("Primero crea una playlist en la pestaña Playlists"); return@launch }
            val names = Array(arr.length()) { arr.getJSONObject(it).getString("nombre") }
            AlertDialog.Builder(requireContext()).setTitle("Agregar a playlist").setItems(names) { _, i ->
                viewLifecycleOwner.lifecycleScope.launch {
                    val rr = Api.call("playlist_add", "user_id" to Session.userId,
                        "playlist_id" to arr.getJSONObject(i).getInt("id"), "song_id" to song.id)
                    toast(rr.optString("msg"))
                }
            }.show()
        }
    }

    private fun removeFromPlaylist(song: Song) {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("playlist_remove", "user_id" to Session.userId, "playlist_id" to playlistId, "song_id" to song.id)
            toast(r.optString("msg")); load()
        }
    }

    private fun toast(m: String) { context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() } }

    companion object {
        fun newInstance(mode: String, pid: Int = 0, pname: String = "") = SongsFragment().apply {
            arguments = Bundle().apply { putString("mode", mode); putInt("pid", pid); putString("pname", pname) }
        }
    }
}

/** Dibuja cada fila: número, PORTADA REAL (o degradado), título/artista, ♥ y ＋. La canción que suena va en rojo. */
class SongAdapter(
    private val inPlaylist: Boolean,
    private val onPlay: (List<Song>, Int) -> Unit,
    private val onFav: (Song) -> Unit,
    private val onMore: (Song) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {
    var items: List<Song> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.tvNum)
        val cover: ImageView = v.findViewById(R.id.viewCover)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val fav: TextView = v.findViewById(R.id.btnFav)
        val more: TextView = v.findViewById(R.id.btnMore)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_song, p, false))
    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val s = items[i]
        val ctx = h.itemView.context
        val playing = PlayerManager.current?.id == s.id
        h.num.text = if (playing) "▶" else "${i + 1}"
        h.num.setTextColor(ContextCompat.getColor(ctx, if (playing) R.color.mf_red else R.color.mf_muted))
        h.cover.setBackgroundResource(Covers.of(s.id))
        CoverLoader.bind(h.cover, s)
        h.title.text = s.title
        h.title.setTextColor(ContextCompat.getColor(ctx, if (playing) R.color.mf_red else R.color.mf_text))
        h.sub.text = "${s.artist} · ${s.genre}"
        h.fav.text = if (s.fav) "♥" else "♡"
        h.more.text = if (inPlaylist) "✕" else "＋"
        h.itemView.setBackgroundResource(if (playing) R.drawable.bg_card_active else R.drawable.bg_card)
        h.itemView.setOnClickListener { onPlay(items, h.bindingAdapterPosition) }
        h.fav.setOnClickListener { onFav(s) }
        h.more.setOnClickListener { onMore(s) }
    }
}