package com.musicflow.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch
import android.widget.ImageView

/**
 * PANTALLA PRINCIPAL. Encabezado (logo, notificaciones, avatar con "Cerrar sesión"),
 * 3 secciones en la barra inferior: Inicio, Biblioteca (Favoritos + Playlist) e Historial,
 * y el mini reproductor. Al empezar una canción se registra en el historial.
 */
class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var nav: BottomNavigationView
    private lateinit var player: LinearLayout
    private lateinit var tvSong: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTime: TextView
    private lateinit var btnPlay: Button
    private lateinit var seek: SeekBar
    private lateinit var viewCover: ImageView
    private var dragging = false

    private var pendingLibraryTab = 0          // 0 = Favoritos, 1 = Playlist
    private val ticker = object : Runnable {
        override fun run() { updateProgress(); handler.postDelayed(this, 500) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.userId == 0) { startActivity(Intent(this, AuthActivity::class.java)); finish(); return }
        setContentView(R.layout.activity_main)

        // Avatar con la inicial del usuario; al tocarlo aparece "Cerrar sesión" (HU03)
        findViewById<TextView>(R.id.tvAvatar).text = Session.name.trim().take(1).uppercase().ifEmpty { "J" }
        findViewById<View>(R.id.avatarBox).setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }
        findViewById<View>(R.id.btnBell).setOnClickListener {
            Toast.makeText(this, "No tienes notificaciones nuevas", Toast.LENGTH_SHORT).show()
        }

        nav = findViewById(R.id.bottomNav)
        nav.setOnItemSelectedListener { show(it.itemId); true }
        show(R.id.nav_home)

        player = findViewById(R.id.player); tvSong = findViewById(R.id.tvSong); tvArtist = findViewById(R.id.tvArtist)
        tvTime = findViewById(R.id.tvTime); btnPlay = findViewById(R.id.btnPlay); seek = findViewById(R.id.seek)
        viewCover = findViewById(R.id.viewCover)
        btnPlay.setOnClickListener { PlayerManager.toggle() }
        player.setOnClickListener { openPlayer() }
        findViewById<Button>(R.id.btnNext).setOnClickListener { PlayerManager.next() }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { PlayerManager.prev() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { PlayerManager.seekTo(seek.progress); dragging = false }
        })

        PlayerManager.onChange = { refreshPlayer() }
        PlayerManager.onPlayed = { song ->
            lifecycleScope.launch { Api.call("history_add", "user_id" to Session.userId, "song_id" to song.id) }
        }
        refreshPlayer()
    }

    private fun logout() {
        PlayerManager.stop(); Session.clear()
        startActivity(Intent(this, AuthActivity::class.java)); finish()
    }

    private fun show(itemId: Int) {
        supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        val f: Fragment = when (itemId) {
            R.id.nav_home -> HomeFragment()
            R.id.nav_library -> {
                val t = pendingLibraryTab; pendingLibraryTab = 0
                LibraryFragment.newInstance(t)
            }
            else -> SongsFragment.newInstance("history")
        }
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
    }

    // ---------- Navegación que usan los demás fragments ----------

    /** Abre una playlist (con botón atrás). La usa PlaylistsFragment. */
    fun openPlaylist(id: Int, name: String) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, SongsFragment.newInstance("playlist", id, name))
            .addToBackStack(null).commit()
    }

    /** Abre el catálogo completo de canciones con su buscador (desde Inicio). */
    fun openCatalog() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, SongsFragment.newInstance("catalog"))
            .addToBackStack(null).commit()
    }

    /** Va a Biblioteca. tab: 0 = Favoritos, 1 = Playlist. */
    fun openLibrary(tab: Int) { pendingLibraryTab = tab; nav.selectedItemId = R.id.nav_library }

    fun openHistory() { nav.selectedItemId = R.id.nav_history }

    // ---------- Mini reproductor ----------
    /** Abre el reproductor expandido a pantalla completa (sube desde abajo). */
    private fun openPlayer() {
        if (PlayerManager.current == null) return
        startActivity(Intent(this, PlayerActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_up, R.anim.stay)
    }
    private fun refreshPlayer() {
        val s = PlayerManager.current
        player.visibility = if (s == null) View.GONE else View.VISIBLE
        if (s != null) {
            tvSong.text = s.title; tvArtist.text = s.artist
            viewCover.setBackgroundResource(Covers.of(s.id))
            CoverLoader.bind(viewCover, s)          // <-- línea nueva: pone la portada real
        }
        btnPlay.text = if (PlayerManager.isPlaying) "⏸" else "▶"
        // resalta la canción que suena en la lista visible
        when (val f = supportFragmentManager.findFragmentById(R.id.container)) {
            is SongsFragment -> f.refreshHighlight()
            is LibraryFragment -> f.refreshHighlight()
        }
    }

    private fun updateProgress() {
        val d = PlayerManager.duration; val p = PlayerManager.position
        if (d > 0 && !dragging) { seek.max = d; seek.progress = p }
        tvTime.text = "${fmt(p)} / ${fmt(d)}"
    }
    private fun fmt(ms: Int) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
        findViewById<TextView>(R.id.tvAvatar).text = Session.name.trim().take(1).uppercase().ifEmpty { "J" }
        loadAvatar()
    }

    /** Pide la foto del usuario al servidor; si no tiene, deja la inicial. */
    private fun loadAvatar() {
        val iv = findViewById<ImageView>(R.id.ivAvatar)
        val tv = findViewById<TextView>(R.id.tvAvatar)
        lifecycleScope.launch {
            val r = Api.call("profile_get", "user_id" to Session.userId)
            if (!r.optBoolean("ok")) return@launch
            val d = r.getJSONObject("data")
            if (d.isNull("foto")) { iv.visibility = View.GONE; tv.visibility = View.VISIBLE; return@launch }
            val bmp = ImageLoader.load(Api.SERVER + "/" + d.getString("foto"))
            if (bmp != null) { iv.setImageBitmap(bmp); iv.visibility = View.VISIBLE; tv.visibility = View.GONE }
        }
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
    override fun onDestroy() {
        super.onDestroy()
        PlayerManager.onChange = null; PlayerManager.onPlayed = null
    }
}