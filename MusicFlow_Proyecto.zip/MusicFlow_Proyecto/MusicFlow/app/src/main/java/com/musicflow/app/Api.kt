package com.musicflow.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** album y cover son opcionales: si la base no los tiene, quedan vacíos. */
data class Song(
    val id: Int, val title: String, val artist: String, val genre: String, val path: String,
    var fav: Boolean, val album: String = "", val cover: String = ""
)

private fun JSONObject.str(k: String) = if (has(k) && !isNull(k)) optString(k) else ""

fun JSONArray.toSongs(): List<Song> = (0 until length()).map {
    val o = getJSONObject(it)
    Song(o.getInt("id"), o.getString("titulo"), o.getString("artista"), o.getString("genero"),
        o.getString("ruta_audio"), o.optInt("fav") == 1, o.str("album"), o.str("portada"))
}

/**
 * CONEXIÓN APP -> XAMPP.
 * Emulador: 10.0.2.2.  Celular real: IP de la PC (ej. http://192.168.1.15/musicflow_api),
 * en la misma red WiFi y con el Firewall de Windows permitiendo Apache.
 */
object Api {
    const val SERVER = "http://10.0.2.2/musicflow_api"

    suspend fun call(action: String, vararg params: Pair<String, Any?>): JSONObject = withContext(Dispatchers.IO) {
        try {
            val conn = URL("$SERVER/api.php?action=$action").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.connectTimeout = 5000; conn.readTimeout = 8000
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject(); params.forEach { body.put(it.first, it.second) }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (conn.responseCode < 400) conn.inputStream else conn.errorStream
            JSONObject(stream.bufferedReader().readText())
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("msg", "Sin conexión con el servidor (¿XAMPP encendido?)")
        }
    }

    /** URL completa de un archivo del servidor (audio o portada), sin doble codificación. */
    fun fileUrl(path: String): String {
        if (path.startsWith("http")) return path
        val clean = path.trimStart('/')
        val encoded = Regex("%[0-9A-Fa-f]{2}").containsMatchIn(clean)
        val finalPath = if (encoded) clean else clean.split("/").joinToString("/") { Uri.encode(it) }
        return "$SERVER/$finalPath"
    }

    fun audioUrl(path: String) = fileUrl(path)
}