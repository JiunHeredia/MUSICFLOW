package com.musicflow.app

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * REPRODUCTOR ÚNICO (HU05-HU08) + shuffle, temporizador de apagado y cola.
 * Lo usan el mini reproductor (onChange) y el expandido (addListener).
 */
object PlayerManager {
    private var mp: MediaPlayer? = null
    private var prepared = false
    private val ui = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Int>()           // índices ya reproducidos (para "anterior")
    private val listeners = mutableListOf<() -> Unit>()

    var queue: List<Song> = emptyList(); private set
    var index = -1; private set
    var isPlaying = false; private set
    var shuffle = false; private set
    var sleepEndsAt = 0L; private set
    val current: Song? get() = queue.getOrNull(index)

    var onChange: (() -> Unit)? = null        // mini reproductor
    var onPlayed: ((Song) -> Unit)? = null    // registra el historial (RN09)

    val position: Int get() = if (prepared) try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 } else 0
    val duration: Int get() = if (prepared) try { mp?.duration ?: 0 } catch (e: Exception) { 0 } else 0

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun notifyChange() { onChange?.invoke(); listeners.toList().forEach { it() } }

    fun playQueue(list: List<Song>, i: Int) { queue = list; history.clear(); play(i, false) }

    private fun play(i: Int, push: Boolean) {
        if (i !in queue.indices) return
        if (push && index in queue.indices) { history.add(index); if (history.size > 50) history.removeAt(0) }
        index = i; prepared = false; isPlaying = false
        mp?.release()
        val song = queue[i]
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(Api.audioUrl(song.path))
            setOnPreparedListener {
                prepared = true; it.start()
                this@PlayerManager.isPlaying = true
                notifyChange(); onPlayed?.invoke(song)
            }
            setOnCompletionListener { this@PlayerManager.next() }
            setOnErrorListener { _, _, _ -> this@PlayerManager.isPlaying = false; notifyChange(); true }
            prepareAsync()
        }
        notifyChange()
    }

    fun toggle() {
        val m = mp ?: return
        if (!prepared) return
        if (m.isPlaying) { m.pause(); isPlaying = false } else { m.start(); isPlaying = true }
        notifyChange()
    }

    fun pause() {
        val m = mp ?: return
        if (prepared && m.isPlaying) { m.pause(); isPlaying = false; notifyChange() }
    }

    fun next() {
        if (queue.isEmpty()) return
        val n = if (shuffle && queue.size > 1) {
            var r = queue.indices.random()
            while (r == index) r = queue.indices.random()
            r
        } else (index + 1) % queue.size
        play(n, true)
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (position > 3000) { seekTo(0); return }
        if (history.isNotEmpty()) play(history.removeAt(history.size - 1), false)
        else play((index - 1 + queue.size) % queue.size, false)
    }

    fun seekTo(ms: Int) { if (prepared) mp?.seekTo(ms) }

    fun toggleShuffle() { shuffle = !shuffle; notifyChange() }

    /** Agrega una canción al final de la cola actual (si no hay nada sonando, la reproduce). */
    fun addToQueue(song: Song) {
        if (queue.isEmpty()) playQueue(listOf(song), 0) else { queue = queue + song; notifyChange() }
    }

    // ----- Temporizador de apagado: pausa la música al cumplirse el tiempo -----
    private val sleepTask = Runnable { sleepEndsAt = 0L; pause(); notifyChange() }
    fun setSleepTimer(minutes: Int) {
        ui.removeCallbacks(sleepTask)
        if (minutes <= 0) sleepEndsAt = 0L
        else { sleepEndsAt = SystemClock.elapsedRealtime() + minutes * 60_000L; ui.postDelayed(sleepTask, minutes * 60_000L) }
        notifyChange()
    }
    fun sleepRemainingMs(): Long =
        if (sleepEndsAt > 0) (sleepEndsAt - SystemClock.elapsedRealtime()).coerceAtLeast(0) else 0L

    fun stop() {
        ui.removeCallbacks(sleepTask); sleepEndsAt = 0L
        mp?.release(); mp = null; prepared = false; isPlaying = false
        queue = emptyList(); index = -1; history.clear()
    }
}