package com.musicflow.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.GridLayoutManager
import kotlinx.coroutines.launch

data class Playlist(val id: Int, val name: String, val total: Int)

/**
 * PESTAÑA PLAYLISTS (HU09). Lista MIS playlists (la API filtra por usuario, RN05/RN10),
 * permite crear una nueva, eliminarla y abrir una para ver/quitar sus canciones.
 */
class PlaylistsFragment : Fragment(R.layout.fragment_playlists) {
    private val items = mutableListOf<Playlist>()
    private lateinit var adapter: PlaylistAdapter
    private lateinit var tvEmpty: TextView

    override fun onViewCreated(v: View, savedInstanceState: android.os.Bundle?) {
        tvEmpty = v.findViewById(R.id.tvEmpty)
        adapter = PlaylistAdapter(items,
            onOpen = { (activity as MainActivity).openPlaylist(it.id, it.name) },
            onDelete = { confirmDelete(it) })
        val rv = v.findViewById<RecyclerView>(R.id.rv)
        rv.layoutManager = GridLayoutManager(requireContext(), 2); rv.adapter = adapter
        v.findViewById<Button>(R.id.btnNew).setOnClickListener { createDialog() }
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        viewLifecycleOwner.lifecycleScope.launch {
            val r = Api.call("playlists", "user_id" to Session.userId)
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@launch }
            val arr = r.getJSONArray("data")
            items.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(Playlist(o.getInt("id"), o.getString("nombre"), o.optInt("total")))
            }
            adapter.notifyDataSetChanged()
            tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun createDialog() {
        val et = EditText(requireContext()); et.hint = "Nombre de la playlist"
        AlertDialog.Builder(requireContext()).setTitle("Nueva playlist").setView(et)
            .setPositiveButton("Crear") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) viewLifecycleOwner.lifecycleScope.launch {
                    val r = Api.call("playlist_create", "user_id" to Session.userId, "nombre" to n)
                    toast(r.optString("msg")); load()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun confirmDelete(p: Playlist) {
        AlertDialog.Builder(requireContext()).setTitle("Eliminar \"${p.name}\"")
            .setMessage("Las canciones seguirán en el catálogo.")
            .setPositiveButton("Eliminar") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    val r = Api.call("playlist_delete", "user_id" to Session.userId, "playlist_id" to p.id)
                    toast(r.optString("msg")); load()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun toast(m: String) { context?.let { Toast.makeText(it, m, Toast.LENGTH_SHORT).show() } }
}

class PlaylistAdapter(
    private val items: List<Playlist>,
    private val onOpen: (Playlist) -> Unit,
    private val onDelete: (Playlist) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvName); val count: TextView = v.findViewById(R.id.tvCount)
        val del: TextView = v.findViewById(R.id.btnDelete)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_playlist, p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val p = items[i]
        h.name.text = p.name; h.count.text = "${p.total} canciones"
        h.itemView.setOnClickListener { onOpen(p) }
        h.del.setOnClickListener { onDelete(p) }
    }
}
